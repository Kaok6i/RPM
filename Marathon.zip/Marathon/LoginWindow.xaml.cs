﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Marathon
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void RefreshTimeLeft()
        {
            DateTime dateTime = DateTime.Now;
            TimeSpan timeSpan = new DateTime(2023, 1, 1, 0, 0, 0) - dateTime;

            if (timeSpan.Days != 0)
            {
                TimeLeftTextBlock.Text = String.Format("До нового года осталось: дней — {0}; часов — {1}", timeSpan.Days, timeSpan.Hours);
            }
            else if (timeSpan.Hours != 0)
            {
                TimeLeftTextBlock.Text = String.Format("До нового года осталось: часов — {0}; минут — {1}", timeSpan.Hours, timeSpan.Minutes);
            }
            else
            {
                TimeLeftTextBlock.Text = String.Format("До нового года осталось: минут — {0}; секунд — {1}", timeSpan.Minutes, timeSpan.Seconds);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Interval = TimeSpan.FromSeconds(1);
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Start();
            RefreshTimeLeft();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            RefreshTimeLeft();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Window window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Window window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            Users.Login(MailTextBox.Text.ToString(), PasswordTextBox.Text.ToString());
        }
    }
}
