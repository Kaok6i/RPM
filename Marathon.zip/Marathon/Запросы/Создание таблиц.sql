drop table Donations
drop table Runners
drop table Coordinators
drop table Administrators
drop table Funds
drop table Users

create table Users
(
ID int identity primary key,
Mail nvarchar(max),
Password nvarchar(max),
Name nvarchar(max),
Surname nvarchar(max),
Patronymic nvarchar(max)
)

create table Funds
(
ID int identity primary key,
Name nvarchar(max),
Info nvarchar(max),
Logo image
)

create table Administrators
(
ID int identity primary key,
UserID int,
foreign key (UserID) references Users(ID)
)

create table Coordinators
(
ID int identity primary key,
UserID int,
foreign key (UserID) references Users(ID)
)

create table Runners
(
ID int identity primary key,
UserID int,
foreign key (UserID) references Users(ID),
FundID int,
foreign key (FundID) references Funds(ID)
)

create table Donations
(
ID int identity primary key,
Donation int,
UserID int,
foreign key (UserID) references Users(ID),
RunnerID int,
foreign key (RunnerID) references Runners(ID)
)