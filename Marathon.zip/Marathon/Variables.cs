﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marathon
{
    public static class Variables
    {
        public static string СonnectionString = @"Data Source=DESKTOP-KVRQN28\SQLEXPRESS;Initial Catalog=MarathonDB;Integrated Security=True";
    }
}
