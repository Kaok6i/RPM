﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace Marathon
{
    public static class Users
    {
        public class User
        {
            public int Id { get; set; }

            public string Mail { get; set; }

            public string Password { get; set; }

            public string Name { get; set; }

            public string Surname { get; set; }

            public string Patronymic { get; set; }

            public User()
            {

            }

            public User (int id, string mail, string password, string name, string surname, string patronymic)
            {
                Id = id;
                Mail = mail;
                Password = password;
                Name = name;
                Surname = surname;
                Patronymic = patronymic;
            }

            public User (User user)
            {
                Id = user.Id;
                Mail = user.Mail;
                Password = user.Password;
                Name = user.Name;
                Surname = user.Surname;
                Patronymic = user.Patronymic;
            }
        }

        public static User CurrentUser = new User();

        public static void Login(string mail, string password)
        {

            using (SqlConnection connection = new SqlConnection(Variables.СonnectionString))
            {
                try
                {
                    connection.Open();

                    string query;

                    SqlCommand command;

                    object result;

                    /* Узнаем число пользователей, имеющих переданные mail и password */

                    query = String.Format("select count(ID) from Users where Mail = '{0}' and Password = '{1}'", mail, password);

                    command = new SqlCommand(query, connection);

                    result = command.ExecuteScalar();

                    if (Convert.ToInt32(result) == 1)
                    {
                        MessageBox.Show("Такой пользователь существует");

                        /* Считываем данные пользователя, имеющего переданные mail и password */

                        query = String.Format("select * from Users where Mail = '{0}'", mail);

                        command = new SqlCommand(query, connection);

                        result = command.ExecuteReader();
                    }
                    else if (Convert.ToInt32(result) == 0)
                    {
                        MessageBox.Show("Такого пользователя не существует");
                    }
                    else
                    {
                        MessageBox.Show("Что-то не так с базой данных");
                    }
                }
                catch
                {
                    MessageBox.Show("Что-то пошло не так...", "Ошибка!", MessageBoxButton.OK);
                }
                finally
                {
                    connection.Close();
                }
            }
        }
    }
}
